#soale 2
#azmoon zahra jalali

x = 3
y = 7

def f(x, y):
    return((x ** 4) + (3*(x**2)) - (6*x) + 4)


def g(x, y):
    return((x**4) + (3*(x**2)) - (6*x) + 16)


def fx(x, y):
    return (4*x)

def gy(x, y):
    return (4*y)


for i in range(10):
    h = (-f(x, y) * gy(x, y) - g(x, y) * gy(x, y)) / (fx(x, y) * gy(x, y)+gy(x, y)*fx(x,y))
    k = (f(x, y) - g(x, y)) * fx(x, y) / (fx(x, y) * gy(x, y) + gy(x, y) * fx(x, y))
    x = x + h
    y = y + k
    print('level ', i, x, y)

