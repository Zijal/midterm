# soale 4
# keshidane yek heyvan be delkhah

from turtle import *

def ring (col, rad):
    fillcolor(col)
    begin_fill()
    circle(rad)
    end_fill()

penup()
goto(-35, 95)
pendown()

ring('black', 15)

penup()
goto(35, 95)
pendown()

ring('black', 15)

penup()
goto(0, 35)
pendown()

ring('white', 40)

penup()
goto(-18, 75)
pendown()

ring('black', 8)

penup()
goto(18, 75)
pendown()

ring('black', 8)

penup()
goto(-18, 77)
pendown()

ring('white', 4)

penup()
goto(18, 77)
pendown()

ring('white', 4)

penup()
goto(0, 55)
pendown()

ring('black', 5)

penup()
goto(0, 55)
pendown()
right(90)
circle(5, 180)
penup()
goto(0, 55)
pendown()
left(360)
circle(5, -180)
hideturtle()

done()