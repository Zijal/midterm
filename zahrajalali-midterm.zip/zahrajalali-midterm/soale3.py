#soale 3
#midterm zahra jalali


import random
b = 3
c = 6


a = []

for i in range(b):
    row = [0] * c
    a += [row]

for i in range(b):
    for j in range(c):
        print(a[i][j], end=' ')
    print()

print('---------------')

for row in a:
    for v in row:
        rand = random.randrange(1, 10)
        print(rand, end=' ')
    print()


