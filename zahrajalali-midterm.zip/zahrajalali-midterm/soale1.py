#Azmoon Zahra Jalali
#neveshtane code melli va bardashtan 3 raghame akhare an

Id_number = '0017560304'[:: -1]

a = '0'
b = '0'
c = '0'

for i in Id_number:
    if i != '0':
        a = i
        break
    else:
        a = Id_number[1]

print(a)


for i in Id_number[1:]:
    if i != '0' and a != Id_number[1]:
        b = i
        break
    else:
        b = Id_number[2]

print(b)


for i in Id_number[2:]:
    if i != '0' and (a and b != Id_number[2] and Id_number[3]):
        c = i
        break
    else:
        c = Id_number[4]

print(c)


#neveshtane a*b name dar liste NAMES
Names = []

for i in range(int(a) * int(b)):
    add = input('Please enter a Girl name: ')
    Names.append(add)

print(Names)



#majmoeye A va B ba c va b ozv va mohasebe ejtema va eshterak

A = ['zahra', 'mahla', 'matin', 'hamid', 'dina', 'omid', 'tina']
B = ['asal', 'omid', 'tina']

ejtema = list(set(A) | set(B))
eshterak = list(set(A) & set(B))

print(ejtema)
print(eshterak)



